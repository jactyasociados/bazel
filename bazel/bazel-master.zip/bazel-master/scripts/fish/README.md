# fish completions

To enable bazel completions, run `bazel build //scripts:fish_completion` and
copy the resulting script from `bazel-bin/scripts/bazel.fish` to
`~/.config/fish/completions/bazel.fish`.
