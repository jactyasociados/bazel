This directory contains files required to build Bazel's website.

The website is built using Jekyll running inside a Docker container.
See the `Dockerfile` for instructions how to test this on your local machine.
